package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import net.minecraft.util.Identifier;

public class Back extends Module {
    private final ModeSetting style = add(new ModeSetting("Style", "Angel Wings", "Dark Wings", "Zeno Wings", "Backpack"));
    private final BoolSetting glow = add(new BoolSetting("Glow", true));

    public Back() {
        super("Back", "Sirta kanat veya sirt cantasi ekler.", Category.COSMETICS);
    }

    public boolean isWings() { return !style.is("Backpack"); }
    public boolean glows() { return glow.get() && isWings(); }

    public Identifier texture() {
        String n;
        switch (style.get()) {
            case "Dark Wings": n = "wings_dark"; break;
            case "Zeno Wings": n = "wings_zeno"; break;
            case "Backpack":   n = "backpack"; break;
            default:           n = "wings_angel"; break;
        }
        return Identifier.of("hile", "textures/back/" + n + ".png");
    }
}
