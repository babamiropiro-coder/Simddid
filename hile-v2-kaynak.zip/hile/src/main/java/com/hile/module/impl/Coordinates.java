package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.gui.DrawContext;

public class Coordinates extends Module {
    public Coordinates() {
        super("Coordinates", "Koordinat ve yon bilgisini gosterir.", Category.RENDER);
        group("Interface");
    }

    @Override public boolean showInList() { return false; }

    @Override
    public void onHud(DrawContext ctx) {
        var p = mc.player;
        if (p == null || mc.options.hudHidden) return;
        String s = "X " + (int) Math.floor(p.getX()) + "   Y " + (int) Math.floor(p.getY()) + "   Z " + (int) Math.floor(p.getZ());
        String dir = p.getHorizontalFacing().asString().substring(0, 1).toUpperCase();
        int w = mc.textRenderer.getWidth(s) + 12 + mc.textRenderer.getWidth(dir) + 12;
        int x = 6, y = mc.getWindow().getScaledHeight() - 24;
        Render2D.round(ctx, x, y, w, 16, 5, Theme.alpha(Theme.card(), 215));
        Render2D.ring(ctx, x, y, w, 16, 5, Theme.alpha(Theme.accent(0), 60));
        ctx.drawText(mc.textRenderer, s, x + 6, y + 4, Theme.text1(), false);
        ctx.drawText(mc.textRenderer, dir, x + w - 6 - mc.textRenderer.getWidth(dir), y + 4, Theme.accentLight(0), false);
    }
}
