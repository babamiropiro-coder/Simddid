package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.BoolSetting;
import com.hile.setting.ColorSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.SoundFx;

public class Interface extends Module {
    private final ModeSetting accent = add(new ModeSetting("Accent", "Blue", "Purple", "Crimson", "Green", "Rainbow", "Custom"));
    private final ColorSetting customAccent = add(new ColorSetting("Custom Accent", 0x3B82F6));
    private final ColorSetting textColor = add(new ColorSetting("Text Color", 0xE9EEFA));
    private final ColorSetting bgColor = add(new ColorSetting("Background", 0x0B0E16));
    private final NumberSetting scale = add(new NumberSetting("Menu Scale", 1.0, 0.6, 1.4, 0.05));
    private final BoolSetting sounds = add(new BoolSetting("Menu Sounds", true));
    private final ModeSetting style = add(new ModeSetting("Sound Pack", "Click", "Pling", "Bell", "Chime", "Arcade", "Crystal", "Soft"));
    private final NumberSetting volume = add(new NumberSetting("Volume", 0.6, 0.1, 1.5, 0.1));

    public Interface() {
        super("Interface", "Menu temasi, renkleri ve sesleri.", Category.CLIENT);
        group("Menu");
    }

    @Override public boolean showInList() { return false; }

    public String accentMode() { return accent.get(); }
    public int accentIndex() { return accent.getIndex(); }
    public void setAccentIndex(int index) {
        for (int i = 0; i < 8 && accent.getIndex() != index; i++) accent.cycle(1);
    }
    public int customAccent() { return customAccent.get(); }
    public int textColor() { return textColor.get(); }
    public int bgColor() { return bgColor.get(); }
    public float menuScale() { return scale.getFloat(); }

    public void resetTheme() {
        customAccent.reset();
        textColor.reset();
        bgColor.reset();
        setAccentIndex(0);
    }

    public ColorSetting customAccentSetting() { return customAccent; }
    public ColorSetting textColorSetting() { return textColor; }
    public ColorSetting bgColorSetting() { return bgColor; }

    private static final String[][] PACKS = {
            {"ui.button.click", "ui.button.click"},
            {"block.note_block.pling", "block.note_block.pling"},
            {"block.note_block.bell", "block.note_block.bell"},
            {"block.amethyst_block.chime", "block.amethyst_block.chime"},
            {"block.note_block.bit", "block.note_block.pling"},
            {"block.amethyst_block.chime", "block.note_block.bell"},
            {"block.note_block.harp", "block.note_block.flute"}
    };

    private void play(float pitch, boolean layer) {
        if (!sounds.get()) return;
        String[] ids = PACKS[Math.min(style.getIndex(), PACKS.length - 1)];
        SoundFx.play(ids[0], pitch, volume.getFloat());
        if (layer && style.getIndex() >= 4) SoundFx.play(ids[1], pitch * 1.5f, volume.getFloat() * 0.7f);
    }

    private static Interface ui() { return ModuleManager.get(Interface.class); }

    public static void playToggle(boolean on) {
        Interface i = ui();
        if (i != null) i.play(on ? 1.5f : 0.9f, on);
    }

    public static void playOpen()  { Interface i = ui(); if (i != null) i.play(1.25f, true); }
    public static void playClose() { Interface i = ui(); if (i != null) i.play(0.8f, false); }
    public static void playTick()  { Interface i = ui(); if (i != null) i.play(1.1f, false); }
}
