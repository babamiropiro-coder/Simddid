package com.hile.module;

import com.hile.module.impl.Interface;
import com.hile.module.impl.Notifications;
import com.hile.setting.Setting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private String group;
    private boolean enabled;
    private int key = -1;
    public boolean keyDown;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    protected void group(String g) { this.group = g; }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public String getGroup() { return group != null ? group : category.label(); }
    public List<Setting> getSettings() { return Collections.unmodifiableList(settings); }
    public boolean isEnabled() { return enabled; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }

    public void setEnabled(boolean value, boolean sound) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
        if (sound) {
            Interface.playToggle(value);
            Notifications.push(name, value);
        }
    }

    public void toggle() { setEnabled(!enabled, true); }

    /** Whether this module shows up in the on-screen module list. */
    public boolean showInList() { return true; }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    /** Called every rendered frame (smooth things like aim assist). */
    public void onFrame() {}
    /** 2D overlay, called every frame while enabled. */
    public void onHud(DrawContext ctx) {}
    /** 3D overlay (world space), called every frame while enabled. */
    public void onRender3D(WorldRenderContext ctx) {}
}
