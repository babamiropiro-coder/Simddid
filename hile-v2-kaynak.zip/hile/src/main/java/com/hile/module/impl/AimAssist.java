package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.TargetUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.util.math.MathHelper;

import java.util.concurrent.ThreadLocalRandom;

public class AimAssist extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 25, 1, 100, 1));
    private final NumberSetting fov = add(new NumberSetting("FOV", 90, 10, 360, 5));
    private final NumberSetting range = add(new NumberSetting("Range", 4.5, 1.0, 8.0, 0.1));
    private final BoolSetting clickOnly = add(new BoolSetting("Only While Clicking", true));
    private final BoolSetting weaponOnly = add(new BoolSetting("Weapon Only", false));
    private final BoolSetting vertical = add(new BoolSetting("Vertical", true));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile Mobs", true));
    private final BoolSetting passive = add(new BoolSetting("Passive Mobs", false));

    private long last = System.nanoTime();

    public AimAssist() {
        super("AimAssist", "Tiklarken hedefe yumusakca yonelir.", Category.COMBAT);
        group("Fighting");
    }

    private static boolean holdingWeapon(net.minecraft.client.network.ClientPlayerEntity p) {
        Item item = p.getMainHandStack().getItem();
        return item instanceof SwordItem || item instanceof AxeItem || item == Items.MACE;
    }

    @Override
    public void onFrame() {
        long now = System.nanoTime();
        double dt = Math.min(2.0, (now - last) / 50_000_000.0);
        last = now;

        var p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;
        if (clickOnly.get() && !mc.options.attackKey.isPressed()) return;
        if (weaponOnly.get() && !holdingWeapon(p)) return;

        LivingEntity target = TargetUtil.find(range.get(), players.get(), hostile.get(), passive.get(),
                false, false, "Angle", fov.get());
        if (target == null) return;

        float[] r = TargetUtil.rotations(target);
        float yawDiff = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float pitchDiff = r[1] - p.getPitch();

        double factor = 1.0 - Math.pow(1.0 - speed.get() / 100.0, dt);
        double jitter = 1.0 + (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.15;

        float dy = MathHelper.clamp((float) (yawDiff * factor * jitter), -10f, 10f);
        float dp = vertical.get() ? MathHelper.clamp((float) (pitchDiff * factor * jitter), -10f, 10f) : 0f;
        if (Math.abs(yawDiff) < 0.2f) dy = 0f;
        if (Math.abs(pitchDiff) < 0.2f) dp = 0f;

        float ny = p.getYaw() + dy;
        float np = MathHelper.clamp(p.getPitch() + dp, -90f, 90f);
        p.setYaw(ny);
        p.setPitch(np);
        p.prevYaw = ny;
        p.prevPitch = np;
    }
}
