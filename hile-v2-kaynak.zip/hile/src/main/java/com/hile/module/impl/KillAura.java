package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.setting.NumberSetting;
import com.hile.util.CombatState;
import com.hile.util.CritUtil;
import com.hile.util.TargetUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

public class KillAura extends Module {
    private static volatile boolean jumpRequested;

    private final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    private final ModeSetting rotate = add(new ModeSetting("Rotation", "Silent", "Smooth", "Off"));
    private final NumberSetting turnSpeed = add(new NumberSetting("Turn Speed", 40, 5, 100, 1));
    private final NumberSetting tolerance = add(new NumberSetting("Aim Tolerance", 14, 4, 60, 1));
    private final ModeSetting crits = add(new ModeSetting("Criticals", "Jump", "Fall", "Off"));
    private final NumberSetting critWait = add(new NumberSetting("Max Crit Wait", 12, 4, 30, 1));
    private final BoolSetting cooldown = add(new BoolSetting("Attack Cooldown", true));
    private final NumberSetting cooldownMin = add(new NumberSetting("Min Charge", 0.95, 0.6, 1.0, 0.05));
    private final NumberSetting cps = add(new NumberSetting("CPS", 10, 1, 20, 1));
    private final ModeSetting sort = add(new ModeSetting("Sort", "Distance", "Health", "Angle"));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile Mobs", true));
    private final BoolSetting passive = add(new BoolSetting("Passive Mobs", false));
    private final BoolSetting invisible = add(new BoolSetting("Invisible", false));
    private final BoolSetting walls = add(new BoolSetting("Through Walls", false));

    private LivingEntity target;
    private int ticks;
    private int waitTicks;
    private long last = System.nanoTime();

    public KillAura() {
        super("KillAura", "Yakindaki hedefe vurur. Critical vurus icin ziplayip dususte vurur.", Category.COMBAT);
        group("Fighting");
    }

    /** Read by the input mixin: make the player jump this tick. */
    public static boolean wantsJump() { return jumpRequested; }

    @Override
    protected void onDisable() {
        jumpRequested = false;
        target = null;
        waitTicks = 0;
    }

    @Override
    public void onTick() {
        jumpRequested = false;
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        ticks++;

        target = TargetUtil.find(range.get(), players.get(), hostile.get(), passive.get(),
                invisible.get(), walls.get(), sort.get(), 360.0);
        if (target == null) {
            waitTicks = 0;
            return;
        }
        CombatState.set(target);

        float need = p.getAttackCooldownProgressPerTick();
        float cd = p.getAttackCooldownProgress(0.5f);
        boolean ready = cooldown.get()
                ? cd >= cooldownMin.getFloat()
                : ticks >= Math.max(1, Math.round(20f / cps.getFloat()));

        boolean critMode = !crits.is("Off");
        boolean possible = CritUtil.possible(p);

        // jump early enough that the fall phase lines up with a fully charged weapon
        if (crits.is("Jump") && possible && p.isOnGround() && !p.isSneaking()) {
            float jumpAt = MathHelper.clamp(1f - 8f / Math.max(need, 1f), 0f, 0.9f);
            if (!cooldown.get() || cd >= jumpAt) jumpRequested = true;
        }
        if (!ready) return;

        boolean crit = CritUtil.canCrit(p);
        if (critMode && possible && !crit) {
            if (++waitTicks <= critWait.getInt()) return;   // wait for the fall, but never stall forever
        }
        waitTicks = 0;
        attack(p, target, critMode && crit);
    }

    private void attack(ClientPlayerEntity p, LivingEntity t, boolean crit) {
        var net = mc.getNetworkHandler();
        if (net == null) return;
        float[] r = TargetUtil.rotations(t);

        if (rotate.is("Silent")) {
            net.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(r[0], r[1], p.isOnGround()));
        } else if (rotate.is("Smooth")) {
            double yawDiff = Math.abs(MathHelper.wrapDegrees(r[0] - p.getYaw()));
            double pitchDiff = Math.abs(r[1] - p.getPitch());
            if (Math.hypot(yawDiff, pitchDiff) > tolerance.get()) return;
        }

        if (crit && p.isSprinting()) {
            // sprinting hits cannot be criticals, so stop sprinting right before the hit
            net.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            p.setSprinting(false);
        }

        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
        ticks = 0;
    }

    /** Smooth mode: the camera follows the target gently every frame. */
    @Override
    public void onFrame() {
        long now = System.nanoTime();
        double dt = Math.min(2.0, (now - last) / 50_000_000.0);
        last = now;

        var p = mc.player;
        if (!rotate.is("Smooth") || p == null || target == null || !target.isAlive() || mc.currentScreen != null) return;

        float[] r = TargetUtil.rotations(target);
        float yawDiff = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float pitchDiff = r[1] - p.getPitch();
        double factor = 1.0 - Math.pow(1.0 - turnSpeed.get() / 100.0, dt);

        float ny = p.getYaw() + (float) (yawDiff * factor);
        float np = MathHelper.clamp(p.getPitch() + (float) (pitchDiff * factor), -90f, 90f);
        p.setYaw(ny);
        p.setPitch(np);
        p.prevYaw = ny;
        p.prevPitch = np;
    }
}
