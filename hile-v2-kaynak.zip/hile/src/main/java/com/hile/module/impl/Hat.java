package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.ModeSetting;

public class Hat extends Module {
    private final ModeSetting style = add(new ModeSetting("Style", "Top Hat", "Crown", "Halo", "Glasses", "Cat Ears"));

    public Hat() {
        super("Hat", "Kafana sapka, tac veya hale ekler.", Category.COSMETICS);
        group("Cosmetics");
    }

    public String style() { return style.get(); }
}
