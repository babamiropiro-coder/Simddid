package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHud extends Module {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.OFFHAND};

    public ArmorHud() {
        super("ArmorHUD", "Zirhini ve dayanikliligini ekranda gosterir.", Category.RENDER);
        group("Interface");
    }

    @Override public boolean showInList() { return false; }

    @Override
    public void onHud(DrawContext ctx) {
        var p = mc.player;
        if (p == null || mc.options.hudHidden) return;
        int n = 0;
        for (EquipmentSlot s : SLOTS) if (!p.getEquippedStack(s).isEmpty()) n++;
        if (n == 0) return;

        int w = n * 20 + 6, h = 26;
        int x = mc.getWindow().getScaledWidth() - w - 6;
        int y = mc.getWindow().getScaledHeight() - h - 6;
        Render2D.round(ctx, x, y, w, h, 6, Theme.alpha(Theme.card(), 215));
        Render2D.ring(ctx, x, y, w, h, 6, Theme.alpha(Theme.accent(0), 60));
        int ix = x + 5;
        for (EquipmentSlot s : SLOTS) {
            ItemStack st = p.getEquippedStack(s);
            if (st.isEmpty()) continue;
            ctx.drawItem(st, ix, y + 5);
            ctx.drawItemInSlot(mc.textRenderer, st, ix, y + 5);
            ix += 20;
        }
    }
}
