package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.setting.NumberSetting;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

public class Notifications extends Module {
    private final NumberSetting duration = add(new NumberSetting("Duration (ms)", 1800, 800, 5000, 100));

    private static final class Entry {
        final String text;
        final boolean on;
        final long born;
        Entry(String text, boolean on) { this.text = text; this.on = on; this.born = System.currentTimeMillis(); }
    }

    private final List<Entry> entries = new ArrayList<>();

    public Notifications() {
        super("Notifications", "Modul acilip kapaninca kucuk bildirim gosterir.", Category.RENDER);
        group("Interface");
    }

    @Override public boolean showInList() { return false; }

    public static void push(String name, boolean on) {
        Notifications n = ModuleManager.get(Notifications.class);
        if (n == null || !n.isEnabled() || name.equals("Notifications")) return;
        n.entries.add(new Entry(name, on));
        while (n.entries.size() > 5) n.entries.remove(0);
    }

    @Override
    public void onHud(DrawContext ctx) {
        if (entries.isEmpty() || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        long now = System.currentTimeMillis();
        long life = duration.getInt();
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();

        int y = sh - 48;
        for (int i = entries.size() - 1; i >= 0; i--) {
            Entry e = entries.get(i);
            long age = now - e.born;
            if (age > life) {
                entries.remove(i);
                continue;
            }
            float in = MathHelper.clamp(age / 180f, 0f, 1f);
            float out = MathHelper.clamp((life - age) / 220f, 0f, 1f);
            float a = Math.min(in, out);
            float slide = (1f - in) * 30f;

            String status = e.on ? "ON" : "OFF";
            int w = 14 + tr.getWidth(e.text) + 10 + tr.getWidth(status) + 10;
            int x = (int) (sw - w - 8 + slide);
            int accent = e.on ? Theme.accent(i * 14) : Theme.text3();
            int al = (int) (230 * a);

            Render2D.round(ctx, x, y, w, 18, 5, Theme.alpha(Theme.card(), al));
            Render2D.ring(ctx, x, y, w, 18, 5, Theme.alpha(accent, (int) (90 * a)));
            Render2D.round(ctx, x + 5, y + 6, 6, 6, 3, Theme.alpha(accent, (int) (255 * a)));
            if (a > 0.05f) {
                ctx.drawText(tr, e.text, x + 16, y + 5, Theme.alpha(Theme.text1(), (int) (255 * a)), false);
                ctx.drawText(tr, status, x + w - tr.getWidth(status) - 8, y + 5, Theme.alpha(accent, (int) (255 * a)), false);
            }
            y -= 22;
        }
    }
}
