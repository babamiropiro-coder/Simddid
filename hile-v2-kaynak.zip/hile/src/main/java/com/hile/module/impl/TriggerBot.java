package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.setting.BoolSetting;
import com.hile.setting.ModeSetting;
import com.hile.util.AntiBotHelper;
import com.hile.util.CombatState;
import com.hile.util.CritUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class TriggerBot extends Module {
    private final ModeSetting crits = add(new ModeSetting("Criticals", "Fall", "Off"));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", true));

    private int wait;

    public TriggerBot() {
        super("TriggerBot", "Nisangah bir hedefin ustundeyken otomatik vurur.", Category.COMBAT);
        group("Fighting");
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof LivingEntity le)) {
            wait = 0;
            return;
        }
        if (le instanceof ArmorStandEntity || !le.isAlive()) return;
        if (le instanceof PlayerEntity pe) {
            if (!players.get() || pe.isSpectator() || AntiBotHelper.isBot(pe)) return;
        } else if (!mobs.get()) {
            return;
        }
        if (p.getAttackCooldownProgress(0.5f) < 0.95f) return;

        boolean critMode = crits.is("Fall");
        boolean crit = CritUtil.canCrit(p);
        if (critMode && CritUtil.possible(p) && !crit && ++wait <= 12) return;
        wait = 0;

        if (critMode && crit && p.isSprinting() && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            p.setSprinting(false);
        }
        CombatState.set(le);
        mc.interactionManager.attackEntity(p, le);
        p.swingHand(Hand.MAIN_HAND);
    }
}
