package com.hile.module.impl;

import com.hile.module.Category;
import com.hile.module.Module;
import com.hile.util.Render2D;
import com.hile.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;

import java.util.ArrayList;
import java.util.List;

public class PotionHud extends Module {
    public PotionHud() {
        super("PotionHUD", "Uzerindeki etkileri ve kalan sureyi gosterir.", Category.RENDER);
        group("Interface");
    }

    @Override public boolean showInList() { return false; }

    @Override
    public void onHud(DrawContext ctx) {
        var p = mc.player;
        if (p == null || mc.world == null || mc.options.hudHidden) return;
        List<StatusEffectInstance> effects = new ArrayList<>(p.getStatusEffects());
        if (effects.isEmpty()) return;

        TextRenderer tr = mc.textRenderer;
        float tickRate = mc.world.getTickManager().getTickRate();
        int x = 6, y = 32;
        for (StatusEffectInstance e : effects) {
            String name = e.getEffectType().value().getName().getString();
            if (e.getAmplifier() > 0) name += " " + (e.getAmplifier() + 1);
            String time = StatusEffectUtil.getDurationText(e, 1.0f, tickRate).getString();
            int w = 24 + Math.max(tr.getWidth(name), tr.getWidth(time)) + 8;

            boolean good = e.getEffectType().value().isBeneficial();
            int col = good ? Theme.accent(0) : 0xFFF87171;
            Render2D.round(ctx, x, y, w, 22, 6, Theme.alpha(Theme.card(), 220));
            Render2D.round(ctx, x + 2, y + 4, 2, 14, 1, col);
            var sprite = mc.getStatusEffectSpriteManager().getSprite(e.getEffectType());
            ctx.drawSprite(x + 7, y + 2, 0, 18, 18, sprite);
            ctx.drawText(tr, name, x + 28, y + 3, Theme.text1(), false);
            ctx.drawText(tr, time, x + 28, y + 12, e.getDuration() < 200 ? 0xFFF87171 : Theme.text2(), false);
            y += 25;
        }
    }
}
