package com.hile.cosmetics;

import com.hile.module.ModuleManager;
import com.hile.module.impl.Back;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/** Wings and backpack, drawn on the player's back. */
public class BackFeatureRenderer extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    private final ModelPart root;

    public BackFeatureRenderer(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context,
                               EntityModelLoader loader) {
        super(context);
        this.root = loader.getModelPart(HatModels.BACK_LAYER);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                       AbstractClientPlayerEntity player, float limbAngle, float limbDistance, float tickDelta,
                       float animationProgress, float headYaw, float headPitch) {
        if (player != MinecraftClient.getInstance().player || player.isInvisible()) return;
        Back back = ModuleManager.get(Back.class);
        if (back == null || !back.isEnabled()) return;
        if (player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return;

        Identifier tex = back.texture();
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(tex));
        int lightCoords = back.glows() ? 0xF000F0 : light;

        matrices.push();
        getContextModel().body.rotate(matrices);

        if (back.isWings()) {
            float flap = 0.45f + 0.22f * MathHelper.sin((player.age + tickDelta) * 0.22f);
            if (player.isOnGround() && player.getVelocity().horizontalLengthSquared() < 0.0004) flap = 0.30f;
            ModelPart l = root.getChild("wing_l");
            ModelPart r = root.getChild("wing_r");
            l.yaw = flap;
            r.yaw = -flap;
            l.render(matrices, vc, lightCoords, OverlayTexture.DEFAULT_UV);
            r.render(matrices, vc, lightCoords, OverlayTexture.DEFAULT_UV);
        } else {
            root.getChild("backpack").render(matrices, vc, lightCoords, OverlayTexture.DEFAULT_UV);
        }
        matrices.pop();
    }
}
