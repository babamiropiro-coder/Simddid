package com.hile.cosmetics;

import com.hile.module.ModuleManager;
import com.hile.module.impl.Hat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class HatFeatureRenderer extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    private static final Identifier TOPHAT = Identifier.of("hile", "textures/hat/tophat.png");
    private static final Identifier CROWN = Identifier.of("hile", "textures/hat/crown.png");
    private static final Identifier GLASSES = Identifier.of("hile", "textures/hat/glasses.png");
    private static final Identifier EARS = Identifier.of("hile", "textures/hat/ears.png");
    private static final Identifier HALO = Identifier.of("hile", "textures/hat/halo.png");

    private final ModelPart root;

    public HatFeatureRenderer(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context,
                              EntityModelLoader loader) {
        super(context);
        this.root = loader.getModelPart(HatModels.LAYER);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                       AbstractClientPlayerEntity player, float limbAngle, float limbDistance, float tickDelta,
                       float animationProgress, float headYaw, float headPitch) {
        if (player != MinecraftClient.getInstance().player || player.isInvisible()) return;
        Hat hat = ModuleManager.get(Hat.class);
        if (hat == null || !hat.isEnabled()) return;

        String partName;
        Identifier texture;
        int lightCoords = light;
        switch (hat.style()) {
            case "Crown":
                partName = "crown";
                texture = CROWN;
                break;
            case "Glasses":
                partName = "glasses";
                texture = GLASSES;
                break;
            case "Cat Ears":
                partName = "ears";
                texture = EARS;
                break;
            case "Halo":
                partName = "halo";
                texture = HALO;
                lightCoords = 0xF000F0;
                break;
            default:
                partName = "tophat";
                texture = TOPHAT;
                break;
        }

        ModelPart part = root.getChild(partName);
        matrices.push();
        getContextModel().head.rotate(matrices);
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(texture));
        part.render(matrices, vc, lightCoords, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }
}
