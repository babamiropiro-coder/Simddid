package com.hile.mixin;

import com.hile.gui.ZenoSplash;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void hile$zenoSplash(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        ZenoSplash.draw(context);
    }
}
