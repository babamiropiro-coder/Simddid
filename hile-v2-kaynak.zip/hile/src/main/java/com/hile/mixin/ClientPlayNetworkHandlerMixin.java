package com.hile.mixin;

import com.hile.module.impl.Velocity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true, require = 0)
    private void hile$velocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        var p = MinecraftClient.getInstance().player;
        if (p != null && Velocity.active() && packet.getEntityId() == p.getId()) {
            Velocity.handle(p, packet);
            ci.cancel();
        }
    }
}
