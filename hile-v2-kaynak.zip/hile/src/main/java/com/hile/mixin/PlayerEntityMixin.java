package com.hile.mixin;

import com.hile.module.impl.SafeWalk;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    /** SafeWalk: behave as if sneaking when it comes to ledges. */
    @Inject(method = "clipAtLedge", at = @At("HEAD"), cancellable = true, require = 0)
    private void hile$safeWalk(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this == MinecraftClient.getInstance().player && SafeWalk.active()) {
            cir.setReturnValue(true);
        }
    }
}
