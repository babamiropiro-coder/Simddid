package com.hile.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class ColorSetting extends Setting {
    private final int def;
    private int rgb;

    public ColorSetting(String name, int rgb) {
        super(name);
        this.def = rgb & 0xFFFFFF;
        this.rgb = def;
    }

    public int get() { return rgb; }
    public int argb() { return 0xFF000000 | rgb; }
    public void set(int v) { rgb = v & 0xFFFFFF; }
    public void reset() { rgb = def; }

    @Override public JsonElement toJson() { return new JsonPrimitive(String.format("#%06X", rgb)); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive()) return;
        try {
            String s = e.getAsString().replace("#", "");
            rgb = Integer.parseInt(s, 16) & 0xFFFFFF;
        } catch (Exception ignored) {
        }
    }
}
