package com.hile.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class SoundFx {
    private SoundFx() {}

    public static void play(String id, float pitch, float volume) {
        try {
            SoundEvent ev = Registries.SOUND_EVENT.get(Identifier.of("minecraft", id));
            if (ev == null) return;
            MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ev, pitch, volume));
        } catch (Throwable ignored) {
        }
    }
}
