package com.hile.util;

import com.hile.module.impl.AntiBot;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class TargetUtil {
    private TargetUtil() {}

    public static float[] rotations(Entity e) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        Vec3d eye = p.getEyePos();
        double dx = e.getX() - eye.x;
        double dy = (e.getY() + e.getHeight() * 0.75) - eye.y;
        double dz = e.getZ() - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        return new float[]{yaw, MathHelper.clamp(pitch, -90f, 90f)};
    }

    public static float[] rotationsTo(Vec3d point) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        Vec3d eye = p.getEyePos();
        double dx = point.x - eye.x;
        double dy = point.y - eye.y;
        double dz = point.z - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        return new float[]{yaw, MathHelper.clamp(pitch, -90f, 90f)};
    }

    public static LivingEntity find(double range, boolean players, boolean hostile, boolean passive,
                                    boolean invisible, boolean walls, String sort, double fov) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return null;

        Vec3d eye = p.getEyePos();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le instanceof ArmorStandEntity) continue;

            if (le instanceof PlayerEntity pe) {
                if (!players || pe.isSpectator() || AntiBot.isBot(pe)) continue;
            } else if (le instanceof Monster) {
                if (!hostile) continue;
            } else if (le instanceof PassiveEntity) {
                if (!passive) continue;
            } else {
                continue;
            }

            if (!invisible && le.isInvisible()) continue;

            Box box = le.getBoundingBox();
            Vec3d closest = new Vec3d(
                    MathHelper.clamp(eye.x, box.minX, box.maxX),
                    MathHelper.clamp(eye.y, box.minY, box.maxY),
                    MathHelper.clamp(eye.z, box.minZ, box.maxZ));
            double dist = eye.distanceTo(closest);
            if (dist > range) continue;

            if (!walls && !p.canSee(le)) continue;

            float[] r = rotations(le);
            double yawDiff = Math.abs(MathHelper.wrapDegrees(r[0] - p.getYaw()));
            double pitchDiff = Math.abs(r[1] - p.getPitch());
            double angle = Math.hypot(yawDiff, pitchDiff);
            if (fov < 360.0 && angle > fov / 2.0) continue;

            double score;
            switch (sort) {
                case "Health": score = le.getHealth(); break;
                case "Angle":  score = angle; break;
                default:       score = dist; break;
            }
            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }
        return best;
    }
}
