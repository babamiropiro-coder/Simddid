package com.hile.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

public final class Render2D {
    private static final Identifier RR = Identifier.of("hile", "textures/gui/rr.png");
    private static final Identifier RING = Identifier.of("hile", "textures/gui/rr_ring.png");
    private static final Identifier GLOW = Identifier.of("hile", "textures/gui/glow.png");

    private Render2D() {}

    /** Legacy scanline rounded rect (no textures). */
    public static void rect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        r = Math.min(r, Math.min(w, h) / 2);
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * (double) r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    private static void nine(DrawContext c, Identifier tex, int x, int y, int w, int h, int r, int argb) {
        int a = (argb >>> 24) & 255;
        if (a == 0 || w <= 0 || h <= 0) return;
        int cr = Math.max(1, Math.min(r, Math.min(w, h) / 2));
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        c.setShaderColor(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, a / 255f);
        c.drawTexture(tex, x, y, cr, cr, 0, 0, 32, 32, 96, 96);
        c.drawTexture(tex, x + w - cr, y, cr, cr, 64, 0, 32, 32, 96, 96);
        c.drawTexture(tex, x, y + h - cr, cr, cr, 0, 64, 32, 32, 96, 96);
        c.drawTexture(tex, x + w - cr, y + h - cr, cr, cr, 64, 64, 32, 32, 96, 96);
        int mw = w - 2 * cr, mh = h - 2 * cr;
        if (mw > 0) {
            c.drawTexture(tex, x + cr, y, mw, cr, 32, 0, 32, 32, 96, 96);
            c.drawTexture(tex, x + cr, y + h - cr, mw, cr, 32, 64, 32, 32, 96, 96);
        }
        if (mh > 0) {
            c.drawTexture(tex, x, y + cr, cr, mh, 0, 32, 32, 32, 96, 96);
            c.drawTexture(tex, x + w - cr, y + cr, cr, mh, 64, 32, 32, 32, 96, 96);
        }
        if (mw > 0 && mh > 0) c.drawTexture(tex, x + cr, y + cr, mw, mh, 32, 32, 32, 32, 96, 96);
        c.setShaderColor(1f, 1f, 1f, 1f);
    }

    /** Anti-aliased filled rounded rectangle. */
    public static void round(DrawContext c, int x, int y, int w, int h, int r, int argb) { nine(c, RR, x, y, w, h, r, argb); }

    /** Anti-aliased rounded outline. */
    public static void ring(DrawContext c, int x, int y, int w, int h, int r, int argb) { nine(c, RING, x, y, w, h, r, argb); }

    /** Soft radial glow tinted with the given rgb. */
    public static void glow(DrawContext c, float cx, float cy, float size, int rgb, float alpha) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        c.setShaderColor(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, alpha);
        c.drawTexture(GLOW, (int) (cx - size / 2f), (int) (cy - size / 2f), (int) size, (int) size, 0, 0, 256, 256, 256, 256);
        c.setShaderColor(1f, 1f, 1f, 1f);
    }

    /** Draws the current theme logo. */
    public static void logo(DrawContext c, int x, int y, int size, float alpha) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        if (Theme.logoTinted()) {
            int a = Theme.accentLight(0);
            c.setShaderColor(((a >> 16) & 255) / 255f, ((a >> 8) & 255) / 255f, (a & 255) / 255f, alpha);
        } else {
            c.setShaderColor(1f, 1f, 1f, alpha);
        }
        c.drawTexture(Theme.logo(), x, y, size, size, 0, 0, 512, 512, 512, 512);
        c.setShaderColor(1f, 1f, 1f, 1f);
    }

    /** Text with an arbitrary design size. align: 0 left, 1 center, 2 right. y is the vertical center. */
    public static void text(DrawContext c, TextRenderer tr, String s, float x, float y, float size, int argb, int align) {
        if (((argb >>> 24) & 255) < 8 || s == null || s.isEmpty()) return;
        float sc = size / 9f;
        float w = tr.getWidth(s) * sc;
        float ox = align == 1 ? x - w / 2f : (align == 2 ? x - w : x);
        var m = c.getMatrices();
        m.push();
        m.translate(ox, y - size / 2f, 0f);
        m.scale(sc, sc, 1f);
        c.drawText(tr, s, 0, 0, argb, false);
        m.pop();
    }

    public static float textWidth(TextRenderer tr, String s, float size) { return tr.getWidth(s) * size / 9f; }
}
