package com.hile.util;

import net.minecraft.entity.LivingEntity;

public final class CombatState {
    private static volatile LivingEntity target;
    private static volatile long time;

    private CombatState() {}

    public static void set(LivingEntity e) {
        target = e;
        time = System.currentTimeMillis();
    }

    public static LivingEntity current(long maxAgeMs) {
        LivingEntity t = target;
        if (t == null || System.currentTimeMillis() - time > maxAgeMs) return null;
        return t;
    }
}
