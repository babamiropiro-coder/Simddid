package com.hile;

import com.hile.cosmetics.BackFeatureRenderer;
import com.hile.cosmetics.HatFeatureRenderer;
import com.hile.cosmetics.HatModels;
import com.hile.gui.ClickGuiScreen;
import com.hile.module.Module;
import com.hile.module.ModuleManager;
import com.hile.module.impl.HitSounds;
import com.hile.util.CombatState;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class HileClient implements ClientModInitializer {
    public static volatile boolean openGuiNext;
    private static KeyBinding guiKey;
    private static int autoSave;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Config.init();

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hile.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.hile"));

        EntityModelLayerRegistry.registerModelLayer(HatModels.LAYER, HatModels::create);
        EntityModelLayerRegistry.registerModelLayer(HatModels.BACK_LAYER, HatModels::createBack);
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, renderer, helper, context) -> {
            if (renderer instanceof PlayerEntityRenderer pr) {
                helper.register(new HatFeatureRenderer(pr, context.getModelLoader()));
                helper.register(new BackFeatureRenderer(pr, context.getModelLoader()));
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiNext && client.currentScreen == null) {
                openGuiNext = false;
                client.setScreen(new ClickGuiScreen());
            }
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
            if (client.player == null || client.world == null) return;

            if (client.currentScreen == null) {
                for (Module m : ModuleManager.getModules()) {
                    if (m.getKey() == -1) continue;
                    boolean down = InputUtil.isKeyPressed(client.getWindow().getHandle(), m.getKey());
                    if (down && !m.keyDown) m.toggle();
                    m.keyDown = down;
                }
            }
            ModuleManager.tick();

            if (++autoSave >= 1200) {   // every minute
                autoSave = 0;
                Config.save();
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            ModuleManager.frame();
            ModuleManager.hud(drawContext);
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(ModuleManager::render3d);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && player == MinecraftClient.getInstance().player) {
                HitSounds.onAttack(entity);
                if (entity instanceof LivingEntity le) CombatState.set(le);
            }
            return ActionResult.PASS;
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("hile").executes(cmd -> {
                    openGuiNext = true;
                    return 1;
                })));
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("zeno").executes(cmd -> {
                    openGuiNext = true;
                    return 1;
                })));

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save());
    }
}
